# Ghost-Droid
# Required active internet connection to start the tool
follow the following steps as it is......

 1. cd Ghost-Droid

 2. chmod 777 setup.sh

 3. ./setup.sh

 4. ./ghost-droid
